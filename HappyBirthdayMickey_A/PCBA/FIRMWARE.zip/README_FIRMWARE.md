# PIC RGB Firmware

Target: **PIC12F1572**

## Behavior

- Drives all 24 common-anode RGB LEDs together using the PIC's three hardware PWM channels.
- `RA0 / PWM2` = red, `RA1 / PWM1` = green, `RA2 / PWM3` = blue.
- PWM polarity is inverted so the PIC **sinks** LED current.
- PWM period is 1024 clocks at a 1 MHz system clock: about **976.6 Hz**.
- Maximum active duty is 255/1024 = **24.9%**.
- RGB anchor values always sum to 255, keeping nominal LED-bank average current approximately constant through mixed colors.
- Sequence: **R -> O -> Y -> G -> B -> I -> V -> I -> B -> G -> Y -> O -> R**, continuously.
- Each transition takes about 6.4 seconds; a complete out-and-back cycle is about **77 seconds**.
- Starts automatically at power-up. No settings, EEPROM, buttons, or user programming.

## Configuration

- Internal oscillator, 1 MHz
- Watchdog OFF
- Power-up timer ON
- MCLR ON
- Brown-out reset ON, high trip point
- PLL OFF
- Low-voltage programming OFF
- CONFIG1 = `0x3FC4`
- CONFIG2 = `0x1AFF`

## Production

Provide `PIC_RGB_Ornament.hex` to PCBWay with the instruction:

> Program U2 (PIC12F1572T-I/MF) before assembly using PIC_RGB_Ornament.hex. 
Do not substitute MCU without approval.

After assembly, apply normal board power, switch ON, and verify all 24 LEDs 
transition smoothly through the full rainbow and back.

## Files

- `FIRMWARE_PIC-RGB.asm` — source corresponding to the production instruction stream.
- `FIRMWARE-HEX_PIC-RGB.hex` — Intel HEX production image for U2.
- `FIRMWARE-ASSY-LISTING_PIC-RGB.lst` — address/opcode listing for audit/debug.

The HEX was generated deterministically from the assembly instruction stream and
validated for Intel HEX checksums, program-memory byte mapping, and 
configuration-word placement. Instruction encodings were independently 
cross-checked against the PIC enhanced-midrange instruction set.
