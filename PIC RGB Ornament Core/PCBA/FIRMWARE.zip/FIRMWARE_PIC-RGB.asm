; PIC RGB Ornament firmware
; Target: PIC12F1572
; Hardware: 24x common-anode RGB LEDs, direct active-low PWM sink
; PWM2/RA0 = RED, PWM1/RA1 = GREEN, PWM3/RA2 = BLUE
; Animation: ROYGBIV -> VIBGYOR, continuous, ~77 s round trip
; Maximum color-bus duty: 255/1024 = 24.9%; R+G+B duty is held constant at 255 counts.
;
; Production HEX was generated from the instruction stream represented by this file.
; Instruction encodings and SFR addresses were cross-checked against the Microchip
; PIC12F1572 data sheet and an independent enhanced-midrange assembler table.

        LIST    P=12F1572
        #include <p12f1572.inc>

        __CONFIG _CONFIG1, _FOSC_INTOSC & _WDTE_OFF & _PWRTE_ON & _MCLRE_ON & _CP_OFF & _BOREN_ON & _CLKOUTEN_OFF
        __CONFIG _CONFIG2, _WRT_OFF & _PLLEN_OFF & _STVREN_ON & _BORV_HI & _LPBOREN_OFF & _DEBUG_OFF & _LVP_OFF

RGB_R   EQU     0x70
RGB_G   EQU     0x71
RGB_B   EQU     0x72
COUNT   EQU     0x73
DELAY1  EQU     0x74
DELAY2  EQU     0x75

        ORG     0x0000
; Reset vector
reset:
        goto    start
start:
        movlb   1
        movlw   0x5A
        movwf   OSCCON
        movlb   2
        movlw   7
        movwf   LATA
        clrf    APFCON
        clrf    CM1CON0
        movlb   3
        clrf    ANSELA
        movlb   1
        movlw   0x38
        movwf   TRISA
        movlw   0xFF
        movwf   RGB_R
        clrf    RGB_G
        clrf    RGB_B
        movlb   0x1B
        clrf    PWM1CLKCON
        clrf    PWM2CLKCON
        clrf    PWM3CLKCON
        clrf    PWM1LDCON
        clrf    PWM2LDCON
        clrf    PWM3LDCON
        clrf    PWM1PHL
        clrf    PWM1PHH
        clrf    PWM2PHL
        clrf    PWM2PHH
        clrf    PWM3PHL
        clrf    PWM3PHH
        movlw   0xFF
        movwf   PWM1PRL
        movlw   3
        movwf   PWM1PRH
        movlw   0xFF
        movwf   PWM2PRL
        movlw   3
        movwf   PWM2PRH
        movlw   0xFF
        movwf   PWM3PRL
        movlw   3
        movwf   PWM3PRH
        clrf    PWM1DCH
        clrf    PWM2DCH
        clrf    PWM3DCH
        clrf    PWM1DCL
        movlw   0xFF
        movwf   PWM2DCL
        clrf    PWM3DCL
        movlw   0x10
        movwf   PWM1CON
        movlw   0x10
        movwf   PWM2CON
        movlw   0x10
        movwf   PWM3CON
        movlw   7
        movwf   PWMLD
        movlw   7
        movwf   PWMEN
        call    delay100
        movlw   0xD0
        movwf   PWM1CON
        movlw   0xD0
        movwf   PWM2CON
        movlw   0xD0
        movwf   PWM3CON
        call    delay100
        movlw   0x40
        movwf   COUNT
r_to_o:
        decf    RGB_R,F
        incf    RGB_G,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    r_to_o
        movlw   0x40
        movwf   COUNT
o_to_y:
        decf    RGB_R,F
        incf    RGB_G,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    o_to_y
        movlw   0x3F
        movwf   COUNT
y_to_g_bulk:
        decf    RGB_R,F
        decf    RGB_R,F
        incf    RGB_G,F
        incf    RGB_G,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    y_to_g_bulk
        decf    RGB_R,F
        incf    RGB_G,F
        call    update_pwm
        call    delay100
        movlw   0x3F
        movwf   COUNT
g_to_b_bulk:
        decf    RGB_G,F
        decf    RGB_G,F
        decf    RGB_G,F
        decf    RGB_G,F
        incf    RGB_B,F
        incf    RGB_B,F
        incf    RGB_B,F
        incf    RGB_B,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    g_to_b_bulk
        decf    RGB_G,F
        decf    RGB_G,F
        decf    RGB_G,F
        incf    RGB_B,F
        incf    RGB_B,F
        incf    RGB_B,F
        call    update_pwm
        call    delay100
        movlw   0x40
        movwf   COUNT
b_to_i:
        incf    RGB_R,F
        decf    RGB_B,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    b_to_i
        movlw   0x40
        movwf   COUNT
i_to_v:
        incf    RGB_R,F
        decf    RGB_B,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    i_to_v
        movlw   0x40
        movwf   COUNT
v_to_i:
        decf    RGB_R,F
        incf    RGB_B,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    v_to_i
        movlw   0x40
        movwf   COUNT
i_to_b:
        decf    RGB_R,F
        incf    RGB_B,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    i_to_b
        movlw   0x3F
        movwf   COUNT
b_to_g_bulk:
        incf    RGB_G,F
        incf    RGB_G,F
        incf    RGB_G,F
        incf    RGB_G,F
        decf    RGB_B,F
        decf    RGB_B,F
        decf    RGB_B,F
        decf    RGB_B,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    b_to_g_bulk
        incf    RGB_G,F
        incf    RGB_G,F
        incf    RGB_G,F
        decf    RGB_B,F
        decf    RGB_B,F
        decf    RGB_B,F
        call    update_pwm
        call    delay100
        movlw   0x3F
        movwf   COUNT
g_to_y_bulk:
        incf    RGB_R,F
        incf    RGB_R,F
        decf    RGB_G,F
        decf    RGB_G,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    g_to_y_bulk
        incf    RGB_R,F
        decf    RGB_G,F
        call    update_pwm
        call    delay100
        movlw   0x40
        movwf   COUNT
y_to_o:
        incf    RGB_R,F
        decf    RGB_G,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    y_to_o
        movlw   0x40
        movwf   COUNT
o_to_r:
        incf    RGB_R,F
        decf    RGB_G,F
        call    update_pwm
        call    delay100
        decfsz  COUNT,F
        goto    o_to_r
        goto    r_to_o
update_pwm:
        movlb   0x1B
        movf    RGB_G,W
        movwf   PWM1DCL
        movf    RGB_R,W
        movwf   PWM2DCL
        movf    RGB_B,W
        movwf   PWM3DCL
        movlw   7
        movwf   PWMLD
        return
delay100:
        movlw   0x21
        movwf   DELAY1
delay_outer:
        movlw   0xFA
        movwf   DELAY2
delay_inner:
        decfsz  DELAY2,F
        goto    delay_inner
        decfsz  DELAY1,F
        goto    delay_outer
        return

        END
